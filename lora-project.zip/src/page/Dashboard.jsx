import React from 'react'
import Sidebar from '../components/Sidebar'
import Layout from '../layouts'

const Dashboard = () => {
    return (
        <Layout>
            <Sidebar></Sidebar>
        </Layout>
    )
}

export default Dashboard
